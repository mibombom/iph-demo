import { integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import type { Course } from "@/lib/courses";

export const courses = pgTable("courses", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  teacher: text("teacher").notNull(),
  subject: text("subject").notNull(),
  tuition: integer("tuition").notNull(),
  seats: integer("seats").notNull(),
  details: jsonb("details").$type<Course>().notNull(),
});

export type EnrollmentItem = { courseId: string; title: string; seats: number; tuition: number };
export type Guardian = { firstName: string; lastName: string; email: string; phone: string; studentName: string; gradeLevel: string };

export const enrollments = pgTable("enrollments", {
  id: uuid("id").defaultRandom().primaryKey(),
  reference: text("reference").notNull().unique(),
  guardian: jsonb("guardian").$type<Guardian>().notNull(),
  items: jsonb("items").$type<EnrollmentItem[]>().notNull(),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull(),
  total: integer("total").notNull(),
  status: text("status").notNull().default("demo_confirmed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const subscribers = pgTable("subscribers", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
