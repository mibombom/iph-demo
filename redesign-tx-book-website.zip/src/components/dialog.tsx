"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";

export default function Dialog({ title, subtitle, onClose, children, drawer = false, wide = false }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode; drawer?: boolean; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    const dialog = ref.current;
    const previous = document.body.style.overflow;
    const previousFocus = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    dialog?.showModal();
    return () => {
      dialog?.close();
      document.body.style.overflow = previous;
      previousFocus?.focus();
    };
  }, []);

  return (
    <dialog ref={ref} className={`store-dialog ${drawer ? "is-drawer" : ""} ${wide ? "is-wide" : ""}`} aria-labelledby="dialog-title" onCancel={(event) => { event.preventDefault(); closeRef.current(); }} onClick={(event) => { if (event.target === event.currentTarget) closeRef.current(); }}>
      <div className="dialog-inner">
        <div className="dialog-heading">
          <div><h2 id="dialog-title">{title}</h2>{subtitle && <p>{subtitle}</p>}</div>
          <button className="icon-button dialog-close" aria-label="Close dialog" onClick={onClose}><X size={21} /></button>
        </div>
        {children}
      </div>
    </dialog>
  );
}
