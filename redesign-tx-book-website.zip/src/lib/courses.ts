export type Course = {
  id: string;
  title: string;
  teacher: string;
  subject: string;
  format: string;
  level: string;
  minGrade: number;
  maxGrade: number;
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  sessions: number;
  minutes: number;
  schedule: string;
  room: string;
  code: string;
  seats: number;
  blurb: string;
  tags: string[];
  teacherPick?: boolean;
  popular?: boolean;
};

export const subjects = ["All classes", "Art & Design", "Science", "Math", "Music", "Writing", "History", "Technology", "Wellness"];

export const subjectArt: Record<string, number> = {
  "Art & Design": 0,
  Science: 1,
  Math: 2,
  Music: 3,
  Writing: 4,
  History: 5,
  Technology: 6,
  Wellness: 7,
};

export const seedCourses: Course[] = [
  { id: "messy-paint-studio", title: "Messy Paint Studio", teacher: "Ms. Elena Ruiz", subject: "Art & Design", format: "Studio", level: "Grades 1–3", minGrade: 1, maxGrade: 3, price: 180, rating: 4.9, reviews: 214, sessions: 10, minutes: 75, schedule: "Tuesdays · 4:00pm", room: "Studio A", code: "ART-110", seats: 6, blurb: "Big brushes, bigger aprons. Young artists explore color mixing, texture and collage with no wrong answers — and everything comes home to hang on the fridge.", tags: ["Hands-on", "Beginner friendly", "Messy fun"], teacherPick: true },
  { id: "clay-and-kiln", title: "Clay & Kiln Workshop", teacher: "Mr. Theo Park", subject: "Art & Design", format: "Workshop", level: "Grades 4–6", minGrade: 4, maxGrade: 6, price: 245, compareAt: 275, rating: 4.8, reviews: 132, sessions: 8, minutes: 90, schedule: "Thursdays · 4:30pm", room: "Kiln Yard", code: "ART-240", seats: 4, blurb: "Pinch pots to proper pottery. Students learn hand-building, glazing and the patience of waiting for the kiln — then take home a set of pieces they actually made.", tags: ["Pottery", "Small group", "Take-home work"] },
  { id: "comics-and-characters", title: "Comics & Character Design", teacher: "Ms. Priya Raman", subject: "Art & Design", format: "Studio", level: "Grades 5–8", minGrade: 5, maxGrade: 8, price: 215, rating: 4.7, reviews: 178, sessions: 10, minutes: 90, schedule: "Wednesdays · 5:00pm", room: "Studio B", code: "ART-320", seats: 9, blurb: "Every student leaves with a finished mini-comic. We cover character sheets, panel layout, inking and the storytelling tricks that make a page turn itself.", tags: ["Illustration", "Storytelling", "Portfolio piece"], popular: true },
  { id: "backyard-naturalists", title: "Backyard Naturalists", teacher: "Mr. Sam Whitfield", subject: "Science", format: "Club", level: "Grades 1–3", minGrade: 1, maxGrade: 3, price: 165, rating: 4.9, reviews: 256, sessions: 8, minutes: 75, schedule: "Mondays · 3:45pm", room: "Garden Lab", code: "SCI-120", seats: 10, blurb: "Magnifying glasses, muddy boots and a field notebook each. We study bugs, seeds and weather right in the school garden, one very good question at a time.", tags: ["Outdoors", "Field notes", "Curiosity first"], teacherPick: true },
  { id: "rockets-and-reactions", title: "Rockets & Reactions Lab", teacher: "Dr. Naomi Cole", subject: "Science", format: "Lab", level: "Grades 4–6", minGrade: 4, maxGrade: 6, price: 230, rating: 4.8, reviews: 190, sessions: 10, minutes: 90, schedule: "Tuesdays · 4:30pm", room: "Lab 2", code: "SCI-260", seats: 5, blurb: "Safe, spectacular chemistry and physics. Students build bottle rockets, test reactions and keep a real lab notebook — goggles very much required.", tags: ["Experiments", "Lab skills", "Wear old clothes"], popular: true },
  { id: "marine-biology-club", title: "Marine Biology Field Club", teacher: "Dr. Naomi Cole", subject: "Science", format: "Club", level: "Grades 6–8", minGrade: 6, maxGrade: 8, price: 260, compareAt: 290, rating: 4.7, reviews: 96, sessions: 6, minutes: 120, schedule: "Saturdays · 9:30am", room: "Lab 1 & shoreline", code: "SCI-340", seats: 0, blurb: "Tide pools, water sampling and microscope work. Six Saturday sessions studying the bay on our doorstep, finishing with a student research showcase.", tags: ["Field trips", "Marine science", "Saturday class"] },
  { id: "math-games-puzzles", title: "Math Games & Puzzles", teacher: "Mr. Dev Anand", subject: "Math", format: "Club", level: "Grades 2–4", minGrade: 2, maxGrade: 4, price: 150, rating: 4.6, reviews: 143, sessions: 10, minutes: 60, schedule: "Wednesdays · 4:00pm", room: "Room 3", code: "MAT-130", seats: 12, blurb: "Logic puzzles, strategy games and number tricks that quietly build real fluency. Perfect for kids who think they don't like math — yet.", tags: ["Games", "Confidence building", "No worksheets"] },
  { id: "mathletes", title: "Mathletes Problem Solving", teacher: "Ms. Grace Okafor", subject: "Math", format: "Seminar", level: "Grades 5–7", minGrade: 5, maxGrade: 7, price: 195, rating: 4.9, reviews: 221, sessions: 12, minutes: 75, schedule: "Thursdays · 4:00pm", room: "Room 5", code: "MAT-280", seats: 7, blurb: "Competition-style problem solving in a team that cheers for good thinking, not fast answers. Students prepare for regional contests each spring.", tags: ["Competition prep", "Team based", "Challenge"], teacherPick: true },
  { id: "algebra-bridge", title: "Intro to Algebra Bridge", teacher: "Ms. Grace Okafor", subject: "Math", format: "Seminar", level: "Grades 7–8", minGrade: 7, maxGrade: 8, price: 240, rating: 4.7, reviews: 118, sessions: 12, minutes: 90, schedule: "Mondays · 5:00pm", room: "Room 5", code: "MAT-350", seats: 3, blurb: "A calm, thorough head start on high-school algebra. Variables, functions and word problems, taught slowly enough that every student keeps up.", tags: ["High school prep", "Small group", "Step by step"] },
  { id: "first-ukulele", title: "First Ukulele", teacher: "Mr. Andre Bell", subject: "Music", format: "Workshop", level: "Grades 1–4", minGrade: 1, maxGrade: 4, price: 170, rating: 4.8, reviews: 167, sessions: 8, minutes: 60, schedule: "Tuesdays · 3:45pm", room: "Music Room", code: "MUS-115", seats: 8, blurb: "Four strings, four chords, one very proud family concert at the end. Instruments provided, and nobody is expected to read music on day one.", tags: ["Instruments provided", "Beginner friendly", "Ends in a concert"] },
  { id: "songwriting-studio", title: "Songwriting Studio", teacher: "Ms. Lena Hart", subject: "Music", format: "Studio", level: "Grades 5–8", minGrade: 5, maxGrade: 8, price: 210, compareAt: 240, rating: 4.9, reviews: 134, sessions: 10, minutes: 90, schedule: "Fridays · 4:30pm", room: "Music Room", code: "MUS-270", seats: 6, blurb: "Write it, play it, record it. Students shape lyrics and melodies into finished songs and leave with a recorded track of their own making.", tags: ["Recording", "Lyrics", "Creative writing"], teacherPick: true, popular: true },
  { id: "jazz-ensemble", title: "School Jazz Ensemble", teacher: "Mr. Andre Bell", subject: "Music", format: "Club", level: "Grades 6–8", minGrade: 6, maxGrade: 8, price: 225, rating: 4.7, reviews: 88, sessions: 14, minutes: 90, schedule: "Wednesdays · 5:30pm", room: "Band Hall", code: "MUS-330", seats: 4, blurb: "For students with a year or two on their instrument. We learn standards, trade solos and play two public gigs — including the spring block party.", tags: ["Ensemble", "Some experience needed", "Live performances"] },
  { id: "storytellers-workshop", title: "Storytellers Workshop", teacher: "Ms. Iris Lang", subject: "Writing", format: "Workshop", level: "Grades 2–4", minGrade: 2, maxGrade: 4, price: 155, rating: 4.8, reviews: 201, sessions: 8, minutes: 60, schedule: "Mondays · 4:00pm", room: "Room 1", code: "WRI-125", seats: 11, blurb: "Wild ideas welcome. Young writers draft, illustrate and bind their own short story, then read it aloud to a very enthusiastic audience of classmates.", tags: ["Creative writing", "Illustrated", "Read aloud"], teacherPick: true },
  { id: "poetry-out-loud", title: "Poetry Out Loud", teacher: "Ms. Iris Lang", subject: "Writing", format: "Workshop", level: "Grades 5–8", minGrade: 5, maxGrade: 8, price: 165, rating: 4.6, reviews: 97, sessions: 8, minutes: 75, schedule: "Thursdays · 5:00pm", room: "Room 2", code: "WRI-265", seats: 9, blurb: "Half writing, half performance. Students find their voice on the page and then, gently and with lots of practice, in front of a room.", tags: ["Performance", "Public speaking", "Confidence building"] },
  { id: "young-journalists", title: "Young Journalists", teacher: "Mr. Caleb Moss", subject: "Writing", format: "Club", level: "Grades 6–8", minGrade: 6, maxGrade: 8, price: 205, rating: 4.7, reviews: 112, sessions: 12, minutes: 90, schedule: "Tuesdays · 5:00pm", room: "Newsroom", code: "WRI-310", seats: 5, blurb: "Students run the school paper: pitching, interviewing, fact-checking and laying out each issue. Real deadlines, real bylines, real printed copies.", tags: ["School newspaper", "Interviewing", "Real deadlines"] },
  { id: "time-travelers", title: "Time Travelers Club", teacher: "Ms. Dana Feld", subject: "History", format: "Club", level: "Grades 3–5", minGrade: 3, maxGrade: 5, price: 160, rating: 4.7, reviews: 129, sessions: 8, minutes: 75, schedule: "Wednesdays · 4:15pm", room: "Room 6", code: "HIS-140", seats: 10, blurb: "One era per session, told through objects, costumes and very good stories. Students build a museum case of their own by the final week.", tags: ["Storytelling", "Hands-on history", "Mini museum"] },
  { id: "ancient-worlds", title: "Ancient Worlds Seminar", teacher: "Mr. Owen Reyes", subject: "History", format: "Seminar", level: "Grades 6–8", minGrade: 6, maxGrade: 8, price: 200, rating: 4.8, reviews: 104, sessions: 10, minutes: 90, schedule: "Mondays · 4:45pm", room: "Room 7", code: "HIS-290", seats: 6, blurb: "Egypt, Greece, Rome and the trade routes between them. A discussion-led class where students argue about evidence like proper historians.", tags: ["Discussion led", "Primary sources", "Debate"] },
  { id: "local-history-walks", title: "Local History Walks", teacher: "Ms. Dana Feld", subject: "History", format: "Club", level: "Grades 4–8", minGrade: 4, maxGrade: 8, price: 175, compareAt: 195, rating: 4.9, reviews: 143, sessions: 6, minutes: 120, schedule: "Saturdays · 10:00am", room: "Meet at the school gate", code: "HIS-315", seats: 8, blurb: "Six Saturday walks through the oldest corners of the neighborhood, mapping what changed and why. Comfortable shoes strongly recommended.", tags: ["Walking class", "Neighborhood", "Saturday class"], popular: true },
  { id: "robotics-sandbox", title: "Robotics Sandbox", teacher: "Mr. Kofi Mensah", subject: "Technology", format: "Lab", level: "Grades 3–5", minGrade: 3, maxGrade: 5, price: 250, rating: 4.9, reviews: 238, sessions: 10, minutes: 90, schedule: "Thursdays · 4:00pm", room: "Maker Lab", code: "TEC-150", seats: 4, blurb: "Build it, break it, build it better. Teams of two design robots that draw, sort and sumo-wrestle, learning to debug together along the way.", tags: ["Team based", "Building", "Problem solving"], teacherPick: true, popular: true },
  { id: "game-design-code", title: "Game Design with Code", teacher: "Ms. Yuki Sato", subject: "Technology", format: "Lab", level: "Grades 5–8", minGrade: 5, maxGrade: 8, price: 265, rating: 4.8, reviews: 186, sessions: 12, minutes: 90, schedule: "Tuesdays · 5:15pm", room: "Computer Lab", code: "TEC-275", seats: 7, blurb: "From sketch to playable. Students design levels, write real code and playtest each other's games, finishing with a public arcade night for families.", tags: ["Coding", "Playtesting", "Arcade night"] },
  { id: "3d-printing", title: "3D Printing & Prototyping", teacher: "Mr. Kofi Mensah", subject: "Technology", format: "Workshop", level: "Grades 6–8", minGrade: 6, maxGrade: 8, price: 285, compareAt: 320, rating: 4.6, reviews: 74, sessions: 8, minutes: 105, schedule: "Fridays · 4:00pm", room: "Maker Lab", code: "TEC-345", seats: 2, blurb: "Modelling, slicing and printing — plus the useful lesson of a failed print. Students prototype a product idea and pitch it in the final session.", tags: ["Design thinking", "Maker skills", "Pitch night"] },
  { id: "playground-yoga", title: "Playground Yoga", teacher: "Ms. Mara Quinn", subject: "Wellness", format: "Workshop", level: "Grades 1–3", minGrade: 1, maxGrade: 3, price: 120, rating: 4.8, reviews: 152, sessions: 8, minutes: 45, schedule: "Fridays · 3:30pm", room: "Gym", code: "WEL-105", seats: 14, blurb: "Stretching, balancing and breathing games that help wiggly bodies wind down at the end of the week. Mats provided, socks optional.", tags: ["Movement", "Calm down", "Mats provided"] },
  { id: "garden-to-kitchen", title: "Garden to Kitchen", teacher: "Mr. Sam Whitfield", subject: "Wellness", format: "Workshop", level: "Grades 3–6", minGrade: 3, maxGrade: 6, price: 190, rating: 4.9, reviews: 176, sessions: 8, minutes: 90, schedule: "Wednesdays · 4:00pm", room: "Teaching Kitchen", code: "WEL-230", seats: 6, blurb: "Pick it, cook it, eat it together. Students grow herbs and vegetables in our raised beds and turn them into something genuinely delicious each week.", tags: ["Cooking", "Gardening", "Family recipes"], teacherPick: true },
  { id: "mindfulness-journaling", title: "Mindfulness & Journaling", teacher: "Ms. Mara Quinn", subject: "Wellness", format: "Seminar", level: "Grades 5–8", minGrade: 5, maxGrade: 8, price: 135, rating: 4.7, reviews: 88, sessions: 6, minutes: 60, schedule: "Thursdays · 3:45pm", room: "Quiet Room", code: "WEL-300", seats: 12, blurb: "A quiet hour for busy minds. Simple breathing practice, honest conversation and a journal that belongs entirely to the student who writes it.", tags: ["Wellbeing", "Quiet class", "Journal included"] },
];

export const money = (amount: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount);

export const BUNDLE_MIN_SEATS = 3;
export const BUNDLE_RATE = 0.1;

export function bundleDiscount(subtotalCents: number, seatCount: number) {
  return seatCount >= BUNDLE_MIN_SEATS ? Math.round(subtotalCents * BUNDLE_RATE) : 0;
}
