import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { courses, enrollments, type EnrollmentItem, type Guardian } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { bundleDiscount } from "@/lib/courses";
import { ensureCatalog } from "@/lib/catalog";

const MAX_SEATS_PER_CLASS = 4;

export async function POST(request: Request) {
  let body;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Please check your enrollment details." }, { status: 400 }); }
  const input = body?.guardian;
  const fields = ["firstName", "lastName", "email", "phone", "studentName", "gradeLevel"] as const;
  if (!input || fields.some((key) => typeof input[key] !== "string" || !input[key].trim() || input[key].length > 254)) {
    return NextResponse.json({ error: "Please fill in every enrollment field." }, { status: 400 });
  }
  const guardian = Object.fromEntries(fields.map((key) => [key, input[key].trim()])) as Guardian;
  guardian.email = guardian.email.toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guardian.email)) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  if (guardian.phone.replace(/\D/g, "").length < 7) return NextResponse.json({ error: "Please enter a phone number we can reach you on." }, { status: 400 });
  if (!Array.isArray(body.items) || body.items.length === 0 || body.items.length > 12) {
    return NextResponse.json({ error: "Please add at least one class to the schedule." }, { status: 400 });
  }
  const requested = new Map<string, number>();
  for (const item of body.items) {
    if (!item || typeof item.courseId !== "string" || !Number.isInteger(item.seats) || item.seats < 1 || item.seats > MAX_SEATS_PER_CLASS) {
      return NextResponse.json({ error: `Please request between 1 and ${MAX_SEATS_PER_CLASS} seats per class.` }, { status: 400 });
    }
    requested.set(item.courseId, (requested.get(item.courseId) || 0) + item.seats);
  }
  if ([...requested.values()].some((seats) => seats > MAX_SEATS_PER_CLASS)) {
    return NextResponse.json({ error: `Please request between 1 and ${MAX_SEATS_PER_CLASS} seats per class.` }, { status: 400 });
  }
  try {
    await ensureCatalog();
    const result = await db.transaction(async (tx) => {
      const rows = await tx.select().from(courses).where(inArray(courses.id, [...requested.keys()])).for("update");
      if (rows.length !== requested.size) throw new Error("A class on your schedule is no longer listed. Please refresh the page.");
      const items: EnrollmentItem[] = rows.map((course) => {
        const seats = requested.get(course.id)!;
        if (course.seats < seats) throw new Error(`Only ${course.seats} seat${course.seats === 1 ? "" : "s"} left in “${course.title}”. Please update the schedule.`);
        return { courseId: course.id, title: course.title, seats, tuition: course.tuition };
      });
      const subtotal = items.reduce((sum, item) => sum + item.tuition * item.seats, 0);
      const seatCount = items.reduce((sum, item) => sum + item.seats, 0);
      const discount = bundleDiscount(subtotal, seatCount);
      const reference = `LA-${randomUUID().slice(0, 8).toUpperCase()}`;
      await tx.insert(enrollments).values({ reference, guardian, items, subtotal, discount, total: subtotal - discount });
      for (const course of rows) await tx.update(courses).set({ seats: course.seats - requested.get(course.id)! }).where(eq(courses.id, course.id));
      return { reference, subtotal: subtotal / 100, discount: discount / 100, total: (subtotal - discount) / 100 };
    });
    return NextResponse.json({ ...result, message: "This demo enrollment has been saved. No payment was taken and no seat is actually reserved." }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && (error.message.startsWith("Only ") || error.message.startsWith("A class"))) return NextResponse.json({ error: error.message }, { status: 409 });
    console.error("Enrollment failed", error);
    return NextResponse.json({ error: "We couldn't save this enrollment just now. Please try again." }, { status: 503 });
  }
}
