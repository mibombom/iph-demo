"use client";

import { ArrowUpRight, Calculator, Check, Cpu, FlaskConical, Heart, Landmark, Music2, Palette, PenLine, Plus, Sprout, type LucideIcon } from "lucide-react";
import { money, subjectArt, type Course } from "@/lib/courses";

export const subjectIcons: Record<string, LucideIcon> = {
  "Art & Design": Palette,
  Science: FlaskConical,
  Math: Calculator,
  Music: Music2,
  Writing: PenLine,
  History: Landmark,
  Technology: Cpu,
  Wellness: Sprout,
};

export const teacherNotes: Record<string, { quote: string; name: string }> = {
  "messy-paint-studio": { quote: "Every single term, somebody in this room discovers they're an artist.", name: "Ms. Ruiz" },
  "backyard-naturalists": { quote: "They arrive curious and leave with a notebook full of better questions.", name: "Mr. Whitfield" },
  "mathletes": { quote: "They cheer for each other's thinking. That's the whole point of it.", name: "Ms. Okafor" },
  "storytellers-workshop": { quote: "Reading their own story out loud changes how they see themselves.", name: "Ms. Lang" },
  "songwriting-studio": { quote: "By the last week, they have a song that is completely theirs.", name: "Ms. Hart" },
  "robotics-sandbox": { quote: "Nothing works the first time. That's exactly where the learning lives.", name: "Mr. Mensah" },
  "garden-to-kitchen": { quote: "Children will happily try anything they grew with their own hands.", name: "Mr. Whitfield" },
};

export function CourseTile({ course, className = "" }: { course: Course; className?: string }) {
  const Icon = subjectIcons[course.subject] ?? Palette;
  return (
    <div className={`course-tile art-${subjectArt[course.subject] ?? 0} ${className}`} aria-hidden="true">
      <span className="tile-top"><Icon strokeWidth={1.35} /></span>
      <span className="tile-bottom"><small>{course.code}</small><strong>{course.subject}</strong></span>
    </div>
  );
}

export function SeatNote({ course }: { course: Course }) {
  const low = course.seats > 0 && course.seats <= 4;
  return (
    <span className={`seat-note ${course.seats === 0 ? "is-full" : low ? "is-low" : ""}`}>
      <span />{course.seats === 0 ? "Class full · waitlist" : `${course.seats} seat${course.seats === 1 ? "" : "s"} left`}
    </span>
  );
}

export default function CourseCard({ course, saved, onSave, onOpen, onAdd, pick = false, index = 0, onSchedule = false }: { course: Course; saved: boolean; onSave: (id: string) => void; onOpen: (course: Course) => void; onAdd: (course: Course) => void; pick?: boolean; index?: number; onSchedule?: boolean }) {
  const note = teacherNotes[course.id];
  return (
    <article className={`course-card ${pick ? "pick-card" : ""}`}>
      <div className={`tile-stage tone-${index % 5}`}>
        <button className="tile-open" aria-label={`See class details for ${course.title}`} onClick={() => onOpen(course)}><CourseTile course={course} /><span className="quick-view">See class details <ArrowUpRight size={14} /></span></button>
        {course.compareAt ? <span className="course-tag">EARLY-BIRD RATE</span> : course.popular ? <span className="course-tag">FAMILY FAVORITE</span> : pick ? <span className="course-tag">TEACHER PICK</span> : null}
        <button className={`save-course ${saved ? "is-saved" : ""}`} aria-label={`${saved ? "Remove" : "Save"} ${course.title} ${saved ? "from your shortlist" : "to your shortlist"}`} aria-pressed={saved} onClick={() => onSave(course.id)}><Heart size={16} fill={saved ? "currentColor" : "none"} /></button>
      </div>
      <div className="course-card-info">
        <span className="course-meta">{course.subject} · {course.level}</span>
        <button className="course-title" onClick={() => onOpen(course)}>{course.title}</button>
        <p className="course-teacher">with {course.teacher}</p>
        <p className="course-when">{course.schedule} · {course.sessions} sessions</p>
        <div className="course-price-row">
          <div><strong>{money(course.price)}</strong>{course.compareAt && <span className="old-price">{money(course.compareAt)}</span>}</div>
          <button className={`add-course ${onSchedule ? "on-schedule" : ""}`} aria-label={course.seats ? `Add ${course.title} to your schedule` : `${course.title} is full`} disabled={course.seats === 0} onClick={() => onAdd(course)}>{onSchedule ? <Check size={17} /> : <Plus size={18} />}</button>
        </div>
        <SeatNote course={course} />
        {pick && note && <p className="teacher-note">“{note.quote}” <span>— {note.name}</span></p>}
      </div>
    </article>
  );
}
