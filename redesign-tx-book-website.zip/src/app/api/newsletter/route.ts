import { NextResponse } from "next/server";
import { db } from "@/db";
import { subscribers } from "@/db/schema";

export async function POST(request: Request) {
  let body;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 }); }
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  }
  try {
    await db.insert(subscribers).values({ email }).onConflictDoNothing();
    return NextResponse.json({ message: "You're on the list. Here's to your next great read!" });
  } catch (error) {
    console.error("Newsletter signup failed", error);
    return NextResponse.json({ error: "We couldn't save your email just now. Please try again." }, { status: 503 });
  }
}
