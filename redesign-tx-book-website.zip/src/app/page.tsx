import Storefront from "@/components/storefront";
import { getCatalog } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const courses = await getCatalog();
  return <Storefront initialCourses={courses} />;
}
