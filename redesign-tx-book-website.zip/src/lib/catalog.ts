import { db } from "@/db";
import { courses } from "@/db/schema";
import { seedCourses, type Course } from "@/lib/courses";

let seedPromise: Promise<void> | undefined;

export async function ensureCatalog() {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(courses).values(seedCourses.map((course) => ({
        id: course.id,
        title: course.title,
        teacher: course.teacher,
        subject: course.subject,
        tuition: Math.round(course.price * 100),
        seats: course.seats,
        details: course,
      }))).onConflictDoNothing();
    })().catch((error) => { seedPromise = undefined; throw error; });
  }
  await seedPromise;
}

export async function getCatalog(): Promise<Course[]> {
  await ensureCatalog();
  const rows = await db.select().from(courses);
  const byId = new Map(rows.map((row) => [row.id, { ...row.details, price: row.tuition / 100, seats: row.seats }]));
  return seedCourses.flatMap((course) => byId.has(course.id) ? [byId.get(course.id)!] : []);
}
