import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://lanternacademy.school"),
  title: "Lantern Academy — Where curiosity goes to class.",
  description: "An independent school and learning studio for grades 1–8. Twelve students per class, specialist teachers, and after-school classes in art, science, math, music, writing, history, technology and wellness.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "Lantern Academy — Where curiosity goes to class.",
    description: "Small classes, real projects and teachers who know every name. Browse this term's class list and enroll.",
    type: "website",
    images: [{ url: "/images/classroom.jpg", width: 1300, height: 880, alt: "A teacher working with students at Lantern Academy" }],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preload" href="/fonts/dm-sans-regular.ttf" as="font" type="font/ttf" crossOrigin="anonymous" />
        <link rel="preload" href="/fonts/libre-caslon-display.ttf" as="font" type="font/ttf" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
