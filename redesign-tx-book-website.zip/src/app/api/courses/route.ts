import { NextRequest, NextResponse } from "next/server";
import { getCatalog } from "@/lib/catalog";

export async function GET(request: NextRequest) {
  try {
    const query = (request.nextUrl.searchParams.get("q") || "").trim().toLowerCase();
    const subject = request.nextUrl.searchParams.get("subject");
    let courses = await getCatalog();
    if (query) courses = courses.filter((course) => `${course.title} ${course.teacher} ${course.code} ${course.tags.join(" ")}`.toLowerCase().includes(query));
    if (subject && subject !== "All classes") courses = courses.filter((course) => course.subject === subject);
    return NextResponse.json({ courses, total: courses.length });
  } catch (error) {
    console.error("Class list request failed", error);
    return NextResponse.json({ error: "The class list is taking a moment to load. Please try again." }, { status: 503 });
  }
}
