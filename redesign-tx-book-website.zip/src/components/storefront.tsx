"use client";

/* eslint-disable @next/next/no-img-element */
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, Asterisk, CalendarDays, Check, CheckCheck, ChevronDown, ChevronLeft, ChevronRight, ClipboardCheck, Clock3, GraduationCap, Hammer, Heart, HeartHandshake, Mail, MapPin, Menu, Minus, NotebookPen, Plus, Search, ShieldCheck, Sparkles, Star, Trash2, Users, X } from "lucide-react";
import { BUNDLE_MIN_SEATS, bundleDiscount, money, subjects, type Course } from "@/lib/courses";
import CourseCard, { CourseTile, SeatNote, teacherNotes } from "@/components/course-card";
import Dialog from "@/components/dialog";

const pickOrder = ["messy-paint-studio", "backyard-naturalists", "mathletes", "storytellers-workshop", "songwriting-studio", "robotics-sandbox", "garden-to-kitchen"];
const MAX_SEATS = 4;
type PlanItem = { id: string; seats: number };
type Panel = "schedule" | "shortlist" | "enroll" | "success" | "visit" | "tuition" | "withdrawal" | "privacy" | null;
type Enrollment = { reference: string; total: number; email: string; student: string };

function Brand() {
  return <span className="brand"><GraduationCap className="brand-icon" size={37} strokeWidth={1.45} /><span className="brand-type">Lantern<span>ACADEMY</span></span></span>;
}

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Storefront({ initialCourses }: { initialCourses: Course[] }) {
  const [courses, setCourses] = useState(initialCourses);
  const [query, setQuery] = useState("");
  const [subject, setSubject] = useState("All classes");
  const [sort, setSort] = useState("recommended");
  const [format, setFormat] = useState("all");
  const [gradeBand, setGradeBand] = useState("all");
  const [seatsOnly, setSeatsOnly] = useState(false);
  const [earlyBird, setEarlyBird] = useState(false);
  const [picksOnly, setPicksOnly] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(8);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [plan, setPlan] = useState<PlanItem[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [detailSeats, setDetailSeats] = useState(1);
  const [toast, setToast] = useState("");
  const [toastTarget, setToastTarget] = useState<"schedule" | "shortlist">("schedule");
  const [newsletterState, setNewsletterState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [newsletterMessage, setNewsletterMessage] = useState("");
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [enrollLoading, setEnrollLoading] = useState(false);
  const [enrollError, setEnrollError] = useState("");
  const [enrollment, setEnrollment] = useState<Enrollment | null>(null);
  const [shelfLeft, setShelfLeft] = useState(false);
  const [shelfRight, setShelfRight] = useState(true);
  const shelfRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLFormElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const courseMap = useMemo(() => new Map(courses.map((course) => [course.id, course])), [courses]);
  const pickedCourses = useMemo(() => pickOrder.flatMap((id) => courseMap.has(id) ? [courseMap.get(id)!] : []), [courseMap]);
  const planCourses = plan.flatMap((item) => courseMap.has(item.id) ? [{ course: courseMap.get(item.id)!, seats: item.seats }] : []);
  const seatCount = plan.reduce((total, item) => total + item.seats, 0);
  const subtotalCents = planCourses.reduce((total, item) => total + Math.round(item.course.price * 100) * item.seats, 0);
  const discountCents = bundleDiscount(subtotalCents, seatCount);
  const subtotal = subtotalCents / 100;
  const discount = discountCents / 100;
  const activeFilters = Number(seatsOnly) + Number(earlyBird) + Number(picksOnly) + Number(format !== "all") + Number(gradeBand !== "all");

  useEffect(() => {
    try {
      const storedPlan: unknown = JSON.parse(localStorage.getItem("lantern-schedule") || "[]");
      const storedSaved: unknown = JSON.parse(localStorage.getItem("lantern-shortlist") || "[]");
      if (Array.isArray(storedPlan)) setPlan(storedPlan.filter((item): item is PlanItem => Boolean(item && typeof item.id === "string" && Number.isInteger(item.seats) && item.seats > 0 && initialCourses.some((course) => course.id === item.id))).map((item) => ({ ...item, seats: Math.min(item.seats, MAX_SEATS, initialCourses.find((course) => course.id === item.id)!.seats) })).filter((item) => item.seats > 0));
      if (Array.isArray(storedSaved)) setSaved(storedSaved.filter((id): id is string => typeof id === "string" && initialCourses.some((course) => course.id === id)));
    } catch { /* A private browser can still use the site without local storage. */ }
    setHydrated(true);
  }, [initialCourses]);

  useEffect(() => {
    if (!hydrated) return;
    try { localStorage.setItem("lantern-schedule", JSON.stringify(plan)); localStorage.setItem("lantern-shortlist", JSON.stringify(saved)); } catch { /* Storage is optional. */ }
  }, [plan, saved, hydrated]);

  useEffect(() => { setVisibleCount(8); }, [query, subject, sort, format, gradeBand, seatsOnly, earlyBird, picksOnly]);

  useEffect(() => {
    const handleClick = (event: MouseEvent) => { if (!searchRef.current?.contains(event.target as Node)) setSearchOpen(false); };
    document.addEventListener("click", handleClick);
    return () => { document.removeEventListener("click", handleClick); if (toastTimer.current) clearTimeout(toastTimer.current); };
  }, []);

  useEffect(() => {
    const element = shelfRef.current;
    if (!element) return;
    const update = () => { setShelfLeft(element.scrollLeft > 8); setShelfRight(element.scrollLeft + element.clientWidth < element.scrollWidth - 8); };
    const observer = new ResizeObserver(update);
    observer.observe(element);
    element.addEventListener("scroll", update);
    update();
    return () => { observer.disconnect(); element.removeEventListener("scroll", update); };
  }, []);

  useEffect(() => { if (mobileSearch) searchInputRef.current?.focus(); }, [mobileSearch]);

  const searchMatches = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return [];
    return courses.filter((course) => `${course.title} ${course.teacher} ${course.subject} ${course.code} ${course.tags.join(" ")}`.toLowerCase().includes(term));
  }, [courses, query]);

  const filteredCourses = useMemo(() => {
    const term = query.trim().toLowerCase();
    const result = courses.filter((course) => {
      if (term && !`${course.title} ${course.teacher} ${course.subject} ${course.code} ${course.tags.join(" ")}`.toLowerCase().includes(term)) return false;
      if (subject !== "All classes" && course.subject !== subject) return false;
      if (seatsOnly && course.seats === 0) return false;
      if (earlyBird && !course.compareAt) return false;
      if (picksOnly && !course.teacherPick) return false;
      if (format !== "all" && course.format !== format) return false;
      if (gradeBand === "lower" && course.minGrade > 3) return false;
      if (gradeBand === "middle" && (course.minGrade > 5 || course.maxGrade < 4)) return false;
      if (gradeBand === "upper" && course.maxGrade < 6) return false;
      return true;
    });
    if (sort === "tuition-low") result.sort((a, b) => a.price - b.price);
    if (sort === "tuition-high") result.sort((a, b) => b.price - a.price);
    if (sort === "rating") result.sort((a, b) => b.rating - a.rating);
    if (sort === "grade") result.sort((a, b) => a.minGrade - b.minGrade);
    if (sort === "title") result.sort((a, b) => a.title.localeCompare(b.title));
    return result;
  }, [courses, query, subject, seatsOnly, earlyBird, picksOnly, format, gradeBand, sort]);

  function notify(message: string, target: "schedule" | "shortlist" = "schedule") {
    setToast(message);
    setToastTarget(target);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 4200);
  }

  function addToPlan(course: Course, seats = 1) {
    const existing = plan.find((item) => item.id === course.id)?.seats || 0;
    const limit = Math.min(course.seats, MAX_SEATS);
    if (existing + seats > limit) { notify(`You already have all ${limit} available seat${limit === 1 ? "" : "s"} for this class on the schedule.`); return; }
    setPlan((previous) => previous.some((item) => item.id === course.id) ? previous.map((item) => item.id === course.id ? { ...item, seats: item.seats + seats } : item) : [...previous, { id: course.id, seats }]);
    notify(`“${course.title}” added to your schedule.`);
  }

  function toggleSave(id: string) {
    const isSaved = saved.includes(id);
    setSaved((previous) => isSaved ? previous.filter((item) => item !== id) : [...previous, id]);
    notify(isSaved ? "Class removed from your shortlist." : "Class saved to your shortlist for later.", "shortlist");
  }

  function updateSeats(id: string, delta: number) {
    setPlan((previous) => previous.map((item) => item.id === id ? { ...item, seats: Math.min(item.seats + delta, courseMap.get(id)?.seats || 0, MAX_SEATS) } : item).filter((item) => item.seats > 0));
  }

  function openCourse(course: Course) { setDetailSeats(1); setSelectedCourse(course); setSearchOpen(false); setMobileSearch(false); setPanel(null); }
  function openPanel(next: Panel) { setSelectedCourse(null); setPanel(next); setMobileMenu(false); setSearchOpen(false); }
  function resetFilters() { setQuery(""); setSubject("All classes"); setFormat("all"); setGradeBand("all"); setSeatsOnly(false); setEarlyBird(false); setPicksOnly(false); setSort("recommended"); }
  function browsePicks() { resetFilters(); setPicksOnly(true); scrollToSection("classes"); }
  function runSearch(event: FormEvent) { event.preventDefault(); setSearchOpen(false); setMobileSearch(false); setSubject("All classes"); setPicksOnly(false); scrollToSection("classes"); }
  function browseFromPanel() { setPanel(null); scrollToSection("classes"); }

  async function subscribe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setNewsletterState("loading"); setNewsletterMessage("");
    try {
      const response = await fetch("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: newsletterEmail }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Please try again in a moment.");
      setNewsletterState("success"); setNewsletterMessage(result.message);
    } catch (error) { setNewsletterState("error"); setNewsletterMessage(error instanceof Error ? error.message : "Something went wrong. Please try again."); }
  }

  async function submitEnrollment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setEnrollLoading(true); setEnrollError("");
    const guardian = Object.fromEntries(new FormData(event.currentTarget).entries());
    try {
      const response = await fetch("/api/enrollments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ guardian, items: plan.map((item) => ({ courseId: item.id, seats: item.seats })) }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "We couldn't save this enrollment. Please try again.");
      setEnrollment({ reference: result.reference, total: result.total, email: String(guardian.email), student: String(guardian.studentName) });
      setCourses((previous) => previous.map((course) => ({ ...course, seats: Math.max(0, course.seats - (plan.find((item) => item.id === course.id)?.seats || 0)) })));
      setPlan([]); setPanel("success");
    } catch (error) { setEnrollError(error instanceof Error ? error.message : "Please check your connection and try again."); }
    finally { setEnrollLoading(false); }
  }

  const renderCard = (course: Course, index: number, pick = false) => <CourseCard key={course.id} course={course} index={index} pick={pick} saved={saved.includes(course.id)} onSchedule={plan.some((item) => item.id === course.id)} onSave={toggleSave} onOpen={openCourse} onAdd={addToPlan} />;

  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <div className="announcement"><span>Spring term starts April 8.</span><span className="announcement-divider">✳</span><button onClick={() => openPanel("tuition")}>Save 10% on three or more classes <ArrowUpRight size={13} /></button></div>
      <header className="site-header" id="top">
        <div className="container header-inner">
          <a className="brand-link" href="#top" aria-label="Lantern Academy home"><Brand /></a>
          <nav className="desktop-nav" aria-label="Main navigation"><a href="#classes">Class list</a><a href="#teacher-picks">Teacher picks</a><a href="#our-school">Our school</a><button onClick={() => openPanel("visit")}>Visit campus <ArrowUpRight size={12} /></button></nav>
          <form ref={searchRef} className={`header-search ${mobileSearch ? "mobile-search-open" : ""}`} onSubmit={runSearch} role="search">
            <Search size={17} strokeWidth={1.6} /><input ref={searchInputRef} aria-label="Search classes, teachers, and subjects" placeholder="Search classes and teachers…" value={query} onChange={(event) => { setQuery(event.target.value); setSearchOpen(true); }} onFocus={() => setSearchOpen(true)} onKeyDown={(event) => { if (event.key === "Escape") { setSearchOpen(false); setMobileSearch(false); } }} />
            {query ? <button className="search-clear" type="button" aria-label="Clear search" onClick={() => setQuery("")}><X size={15} /></button> : <kbd>⌕</kbd>}
            {searchOpen && query.trim() && <div className="search-results"><span className="search-heading">{searchMatches.length ? "CLASSES ON THE TIMETABLE" : "NOTHING ON THE TIMETABLE"}</span>{searchMatches.slice(0, 4).map((course) => <button type="button" key={course.id} className="search-result" onClick={() => openCourse(course)}><CourseTile course={course} /><span><strong>{course.title}</strong><small>{course.subject} · {course.level}</small></span><ArrowUpRight size={16} /></button>)}{searchMatches.length ? <button className="search-see-all" type="submit">See all {searchMatches.length} results <ArrowRight size={15} /></button> : <p>No classes matched. Try a subject, teacher, or grade.</p>}</div>}
          </form>
          <div className="header-actions"><button className="icon-button mobile-search-toggle" aria-label="Search classes" onClick={() => { setMobileSearch(!mobileSearch); setMobileMenu(false); }}><Search size={21} /></button><button className="icon-button header-heart" aria-label={`Open shortlist, ${saved.length} saved classes`} onClick={() => openPanel("shortlist")}><Heart size={21} strokeWidth={1.6} />{saved.length > 0 && <span className="tiny-count">{saved.length}</span>}</button><span className="header-action-divider" /><button className="schedule-button" aria-label={`Open class schedule, ${seatCount} seats`} onClick={() => openPanel("schedule")}><CalendarDays size={20} strokeWidth={1.6} /><span className="schedule-label">Schedule</span><span className="schedule-count">{seatCount}</span></button><button className="icon-button mobile-menu-toggle" aria-label={mobileMenu ? "Close menu" : "Open menu"} aria-expanded={mobileMenu} onClick={() => { setMobileMenu(!mobileMenu); setMobileSearch(false); }}><Menu size={22} /></button></div>
        </div>
        {mobileMenu && <nav className="mobile-nav" aria-label="Mobile navigation"><a href="#classes" onClick={() => setMobileMenu(false)}>Class list <ArrowUpRight size={16} /></a><a href="#teacher-picks" onClick={() => setMobileMenu(false)}>Teacher picks <ArrowUpRight size={16} /></a><a href="#our-school" onClick={() => setMobileMenu(false)}>Our school <ArrowUpRight size={16} /></a><button onClick={() => openPanel("visit")}>Visit the campus <ArrowUpRight size={16} /></button></nav>}
      </header>

      <main id="main">
        <section className="hero container" aria-labelledby="hero-title">
          <div className="hero-copy"><p className="eyebrow hero-eyebrow"><span /> AN INDEPENDENT SCHOOL FOR GRADES 1–8</p><h1 id="hero-title">Where curiosity<br /><em>goes to class.</em></h1><p className="hero-description">Twelve students to a room. Teachers who know every name.<br />Afternoons that feel like the best part of the day.</p><div className="hero-buttons"><a className="button button-primary" href="#classes">Browse the class list <ArrowUpRight size={18} /></a><a className="hero-secondary" href="#teacher-picks">What teachers recommend <ArrowRight size={17} /></a></div><div className="reader-proof"><div className="reader-avatars"><img src="/images/family-1.jpg" alt="" /><img src="/images/family-2.jpg" alt="" /><img src="/images/family-3.jpg" alt="" /></div><div><div className="reader-stars" aria-label="Rated 4.9 out of 5 by families">{Array.from({ length: 5 }, (_, i) => <Star key={i} size={11} fill="currentColor" strokeWidth={1} />)}<span>4.9/5</span></div><p>Trusted by 600+ neighborhood families.</p></div></div></div>
          <div className="hero-art"><div className="hero-photo"><img src="/images/classroom.jpg" alt="A teacher working alongside young students at a classroom table" fetchPriority="high" /></div><div className="hero-seal" aria-label="Small classes, big ideas"><Asterisk size={27} strokeWidth={1.3} /><span>SMALL CLASSES.<br />BIG IDEAS.</span></div><button className="hero-note" onClick={() => scrollToSection("teacher-picks")}><span className="note-icon"><NotebookPen size={22} strokeWidth={1.4} /></span><span><small>SPRING TERM · ENROLLING NOW</small><strong>Seats are filling up.</strong></span><ArrowUpRight size={19} /></button><span className="hero-caption">TWELVE STUDENTS PER CLASS. NEVER MORE.</span></div>
        </section>

        <section className="benefits" aria-label="The Lantern Academy promise"><div className="container benefit-grid"><div><Users size={25} strokeWidth={1.35} /><span><strong>Twelve to a class</strong><small>Everyone gets a turn to talk.</small></span></div><div><GraduationCap size={25} strokeWidth={1.35} /><span><strong>Teachers who stay</strong><small>Specialists, not substitutes.</small></span></div><div><Hammer size={25} strokeWidth={1.35} /><span><strong>Learning by making</strong><small>Something finished every term.</small></span></div><div><HeartHandshake size={25} strokeWidth={1.35} /><span><strong>A real community</strong><small>Independent and family-run.</small></span></div></div></section>

        <section className="picks-section container" id="teacher-picks" aria-labelledby="picks-title"><div className="section-heading"><div><p className="eyebrow"><span className="shelf-number">01</span> STRAIGHT FROM THE STAFF ROOM</p><h2 id="picks-title">Classes our <em>teachers love.</em></h2><p className="section-description">The ones they talk about at lunch — and sign their own kids up for.</p></div><div className="section-heading-actions"><button className="text-link" onClick={browsePicks}>All teacher picks <ArrowUpRight size={17} /></button><div className="shelf-controls"><button className="round-button" aria-label="Previous teacher picks" disabled={!shelfLeft} onClick={() => shelfRef.current?.scrollBy({ left: -(shelfRef.current.clientWidth * .83), behavior: "smooth" })}><ChevronLeft size={18} /></button><button className="round-button" aria-label="Next teacher picks" disabled={!shelfRight} onClick={() => shelfRef.current?.scrollBy({ left: shelfRef.current.clientWidth * .83, behavior: "smooth" })}><ChevronRight size={18} /></button></div></div></div><div ref={shelfRef} className="pick-shelf">{pickedCourses.map((course, index) => renderCard(course, index, true))}</div><div className="shelf-footer"><span>EVERY CLASS TAUGHT BY A SPECIALIST.</span><Asterisk size={19} strokeWidth={1} /><span>NO HOMEWORK, WE PROMISE.</span></div></section>

        <section className="catalog-section container" id="classes" aria-labelledby="classes-title"><div className="section-heading"><div><p className="eyebrow"><span className="shelf-number">02</span> SOMETHING FOR EVERY KIND OF LEARNER</p><h2 id="classes-title">Find the <em>right class.</em></h2><p className="section-description">Filter by subject, grade and schedule. Or browse until something clicks.</p></div><div className="catalog-count"><CalendarDays size={17} strokeWidth={1.5} />{courses.length} classes this term</div></div><div className="category-tabs" aria-label="Subjects">{subjects.map((item) => <button key={item} className={subject === item ? "active" : ""} aria-pressed={subject === item} onClick={() => setSubject(item)}>{item}</button>)}</div><div className="catalog-toolbar"><div className="toolbar-left"><button className={`filter-toggle ${filtersOpen ? "is-active" : ""}`} aria-expanded={filtersOpen} aria-controls="class-filters" onClick={() => setFiltersOpen(!filtersOpen)}><ClipboardCheck size={16} /> Filters{activeFilters > 0 && <span>{activeFilters}</span>}</button><span className="result-count" aria-live="polite">{filteredCourses.length} {filteredCourses.length === 1 ? "class" : "classes"}{query && ` for “${query}”`}</span>{picksOnly && <button className="active-filter" onClick={() => setPicksOnly(false)}>Teacher picks <X size={12} /></button>}</div><label className="sort-control"><span>Sort by:</span><select value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort classes"><option value="recommended">Recommended</option><option value="tuition-low">Tuition: low to high</option><option value="tuition-high">Tuition: high to low</option><option value="rating">Highest rated</option><option value="grade">Grade: youngest first</option><option value="title">Title: A–Z</option></select><ChevronDown size={14} /></label></div>
          {filtersOpen && <div className="filter-panel" id="class-filters"><label>Class type<select aria-label="Class type" value={format} onChange={(event) => setFormat(event.target.value)}><option value="all">All types</option><option>Studio</option><option>Lab</option><option>Workshop</option><option>Seminar</option><option>Club</option></select></label><label>Grade band<select aria-label="Grade band" value={gradeBand} onChange={(event) => setGradeBand(event.target.value)}><option value="all">All grades</option><option value="lower">Grades 1–3</option><option value="middle">Grades 4–5</option><option value="upper">Grades 6–8</option></select></label><label className="checkbox-label"><input type="checkbox" checked={seatsOnly} onChange={(event) => setSeatsOnly(event.target.checked)} />Seats available</label><label className="checkbox-label"><input type="checkbox" checked={earlyBird} onChange={(event) => setEarlyBird(event.target.checked)} />Early-bird rate</label><label className="checkbox-label"><input type="checkbox" checked={picksOnly} onChange={(event) => setPicksOnly(event.target.checked)} />Teacher picks</label><button className="text-link" onClick={resetFilters}>Reset all <X size={13} /></button></div>}
          {filteredCourses.length > 0 ? <><div className="catalog-grid">{filteredCourses.slice(0, visibleCount).map((course, index) => renderCard(course, index))}</div><div className="catalog-more"><span>Showing {Math.min(visibleCount, filteredCourses.length)} of {filteredCourses.length} classes</span>{visibleCount < filteredCourses.length ? <button className="button button-outline" onClick={() => setVisibleCount((count) => count + 8)}>Show more classes <ArrowDown size={16} /></button> : (query || subject !== "All classes" || activeFilters > 0) ? <button className="text-link" onClick={resetFilters}>See the whole timetable <ArrowRight size={16} /></button> : <span className="all-classes-note"><CheckCheck size={16} /> That’s every class this term.</span>}</div></> : <div className="empty-state catalog-empty"><Search size={35} strokeWidth={1} /><h3>No classes match just yet.</h3><p>Try another subject or loosen a filter.<br />Our office can also help you find a fit.</p><button className="button button-primary" onClick={resetFilters}>Show all classes <ArrowRight size={16} /></button></div>}
        </section>

        <section className="story-section" id="our-school" aria-labelledby="story-title"><div className="story-image"><img src="/images/campus.jpg" alt="Students and a teacher walking together across the school courtyard" loading="lazy" /><span className="image-caption"><MapPin size={14} /> 901 LANTERN STREET, PROVIDENCE</span></div><div className="story-copy"><p className="eyebrow">INDEPENDENT AND FAMILY-RUN SINCE 2019</p><h2 id="story-title">One small campus.<br /><em>A lot of big ideas.</em></h2><p>We think school should be the part of the day kids look forward to.<br className="desktop-break" /> So we built one around that.</p><p>Two buildings, a garden, a maker lab and a very patient school dog. Every class is capped at twelve students and taught by a specialist who chose to be here.</p><button className="button button-light" onClick={() => openPanel("visit")}>Book a campus visit <ArrowUpRight size={17} /></button><span className="story-signoff">The kettle is always on in the front office.</span></div></section>

        <section className="newsletter-section container" aria-labelledby="newsletter-title"><div className="newsletter-intro"><span className="newsletter-illustration"><Mail size={37} strokeWidth={1} /><Sparkles size={17} strokeWidth={1.3} /></span><div><p className="eyebrow">SCHOOL NOTES · OUR FAMILY NEWSLETTER</p><h2 id="newsletter-title">Term dates and <em>good news.</em></h2><p>New classes, open mornings and the occasional photo of the school dog.<br />Twice a month at most, and never a word of jargon.</p></div></div><div className="newsletter-form-wrap">{newsletterState === "success" ? <div className="newsletter-success" role="status"><Check size={24} /><div><strong>Welcome to the school list.</strong><p>{newsletterMessage}</p></div></div> : <form onSubmit={subscribe}><label className="sr-only" htmlFor="newsletter-email">Your email address</label><div className="newsletter-input"><input id="newsletter-email" type="email" required maxLength={254} value={newsletterEmail} placeholder="Your email address" onChange={(event) => setNewsletterEmail(event.target.value)} /><button aria-label="Subscribe to the Lantern Academy newsletter" disabled={newsletterState === "loading"}>{newsletterState === "loading" ? "Joining…" : "Keep me posted"}<ArrowUpRight size={17} /></button></div><p className={newsletterState === "error" ? "form-error" : "newsletter-footnote"} role={newsletterState === "error" ? "alert" : undefined}>{newsletterState === "error" ? newsletterMessage : "School news only. Unsubscribe any time."}</p></form>}</div></section>
      </main>

      <footer className="site-footer"><div className="container footer-top"><div className="footer-brand"><a href="#top" aria-label="Lantern Academy home"><Brand /></a><p>An independent school and learning studio<br />for grades 1–8, family-run since 2019.</p><span><Sparkles size={15} strokeWidth={1.5} /> Small by design. Independent by choice.</span></div><div className="footer-column"><h3>EXPLORE THE TERM</h3><a href="#classes" onClick={resetFilters}>The full class list</a><button onClick={browsePicks}>Teacher picks</button><button onClick={() => openPanel("shortlist")}>Your shortlist</button></div><div className="footer-column"><h3>FOR FAMILIES</h3><button onClick={() => openPanel("tuition")}>Tuition & payment</button><button onClick={() => openPanel("withdrawal")}>Enrollment & withdrawal</button><button onClick={() => openPanel("privacy")}>Privacy & your data</button></div><div className="footer-column footer-visit"><h3>THE SCHOOL OFFICE</h3><button onClick={() => openPanel("visit")}>901 Lantern Street<br />Providence, RI 02903 <ArrowUpRight size={15} /></button><p>Mon–Fri 8–6 · Sat 9–2</p><a href="mailto:office@lanternacademy.school">office@lanternacademy.school</a></div></div><div className="container footer-bottom"><p>© {new Date().getFullYear()} Lantern Academy. Every learner welcome.</p><span>Less screen time. <GraduationCap size={15} strokeWidth={1.4} /> More making.</span><button onClick={() => scrollToSection("top")}>Back to top <ArrowUpRight size={14} /></button></div></footer>

      {toast && <div className="toast" role="status"><Check size={18} /><span>{toast}</span><button onClick={() => { setToast(""); openPanel(toastTarget); }}>{toastTarget === "schedule" ? "View schedule" : "View shortlist"} <ArrowRight size={14} /></button><button className="toast-close" aria-label="Dismiss notification" onClick={() => setToast("")}><X size={15} /></button></div>}

      {selectedCourse && <Dialog title="A closer look" subtitle="Everything families ask before they enroll." onClose={() => setSelectedCourse(null)} wide><div className="course-detail"><div className={`detail-art tone-${(selectedCourse.sessions + selectedCourse.minGrade) % 5}`}><CourseTile course={selectedCourse} />{selectedCourse.teacherPick && <span className="detail-pick-tag"><Sparkles size={15} /> A teacher favorite</span>}</div><div className="detail-copy"><span className="eyebrow">{selectedCourse.subject} · {selectedCourse.level}</span><h3>{selectedCourse.title}</h3><p className="detail-teacher">with {selectedCourse.teacher}</p><div className="detail-rating"><Star size={15} fill="currentColor" /><strong>{selectedCourse.rating.toFixed(1)}</strong><span>({selectedCourse.reviews.toLocaleString()} family reviews)</span></div><p className="detail-description">{selectedCourse.blurb}</p>{teacherNotes[selectedCourse.id] && <blockquote>“{teacherNotes[selectedCourse.id].quote}”<cite>— {teacherNotes[selectedCourse.id].name}, class teacher</cite></blockquote>}<div className="course-facts"><div><small>WHEN</small><strong>{selectedCourse.schedule}</strong></div><div><small>CLASS TYPE</small><strong>{selectedCourse.format}</strong></div><div><small>LENGTH</small><strong>{selectedCourse.sessions} sessions · {selectedCourse.minutes} min</strong></div><div><small>WHERE</small><strong>{selectedCourse.room}</strong></div></div><div className="detail-purchase"><div><strong className="detail-price">{money(selectedCourse.price)}</strong>{selectedCourse.compareAt && <span className="old-price">{money(selectedCourse.compareAt)}</span>}<SeatNote course={selectedCourse} /></div><div className="detail-purchase-actions"><div className="quantity-control"><button aria-label="Fewer seats" disabled={detailSeats <= 1} onClick={() => setDetailSeats((seats) => seats - 1)}><Minus size={14} /></button><span>{detailSeats}</span><button aria-label="More seats" disabled={detailSeats >= Math.min(selectedCourse.seats, MAX_SEATS)} onClick={() => setDetailSeats((seats) => seats + 1)}><Plus size={14} /></button></div><button className="button button-primary" disabled={!selectedCourse.seats} onClick={() => { addToPlan(selectedCourse, detailSeats); openPanel("schedule"); }}><CalendarDays size={17} />{selectedCourse.seats ? "Add to schedule" : "Class is full"}</button></div><button className="detail-save" onClick={() => toggleSave(selectedCourse.id)}><Heart size={15} fill={saved.includes(selectedCourse.id) ? "currentColor" : "none"} />{saved.includes(selectedCourse.id) ? "Saved to your shortlist" : "Save to your shortlist"}</button><p className="detail-delivery"><Sparkles size={15} /> Enroll in {BUNDLE_MIN_SEATS} or more seats and save 10%.</p></div></div></div></Dialog>}

      {panel === "schedule" && <Dialog title="Your class schedule" subtitle={`${seatCount} ${seatCount === 1 ? "seat" : "seats"} across ${planCourses.length} ${planCourses.length === 1 ? "class" : "classes"}.`} onClose={() => setPanel(null)} drawer>{planCourses.length ? <><div className="discount-progress"><p><Sparkles size={16} />{seatCount >= BUNDLE_MIN_SEATS ? "Multi-class discount applied — 10% off." : `Add ${BUNDLE_MIN_SEATS - seatCount} more seat${BUNDLE_MIN_SEATS - seatCount === 1 ? "" : "s"} to save 10%.`}</p><div><span style={{ width: `${Math.min(seatCount / BUNDLE_MIN_SEATS * 100, 100)}%` }} /></div></div><div className="plan-items">{planCourses.map(({ course, seats }) => <div className="plan-item" key={course.id}><button className="plan-tile-button" onClick={() => openCourse(course)}><CourseTile course={course} /></button><div className="plan-item-copy"><button className="plan-item-title" onClick={() => openCourse(course)}>{course.title}</button><p>{course.teacher}</p><small>{course.schedule} · {course.room}</small><div className="plan-item-controls"><div className="quantity-control"><button aria-label={`Fewer seats for ${course.title}`} onClick={() => updateSeats(course.id, -1)}><Minus size={13} /></button><span>{seats}</span><button aria-label={`More seats for ${course.title}`} disabled={seats >= Math.min(course.seats, MAX_SEATS)} onClick={() => updateSeats(course.id, 1)}><Plus size={13} /></button></div><strong>{money(course.price * seats)}</strong><button className="remove-item" aria-label={`Remove ${course.title} from the schedule`} onClick={() => setPlan((previous) => previous.filter((item) => item.id !== course.id))}><Trash2 size={15} /></button></div></div></div>)}</div><div className="plan-summary"><div><span>Tuition subtotal</span><span>{money(subtotal)}</span></div><div><span>Multi-class discount</span><span className={discount > 0 ? "discount-applied" : ""}>{discount > 0 ? `− ${money(discount)}` : "—"}</span></div><div className="summary-total"><strong>Total</strong><strong>{money(subtotal - discount)}</strong></div><button className="button button-primary full-width" onClick={() => { setEnrollError(""); setPanel("enroll"); }}>Continue to enrollment <ArrowRight size={17} /></button><button className="continue-browsing" onClick={() => setPanel(null)}>Keep looking at classes</button><span className="checkout-note"><ShieldCheck size={14} /> Demo enrollment · No payment collected</span></div></> : <div className="empty-state drawer-empty"><CalendarDays size={49} strokeWidth={1} /><h3>Your term starts here.</h3><p>No classes on the schedule yet.<br />Add one and we’ll hold your place.</p><button className="button button-primary" onClick={browseFromPanel}>Browse the class list <ArrowRight size={16} /></button></div>}</Dialog>}

      {panel === "shortlist" && <Dialog title="Your shortlist" subtitle="Classes you’re still thinking about." onClose={() => setPanel(null)} drawer>{saved.length ? <><div className="wishlist-intro"><Heart size={17} /><span>{saved.length} {saved.length === 1 ? "class" : "classes"} saved for later.</span></div><div className="plan-items wishlist-items">{saved.flatMap((id) => courseMap.has(id) ? [courseMap.get(id)!] : []).map((course) => <div className="plan-item" key={course.id}><button className="plan-tile-button" onClick={() => openCourse(course)}><CourseTile course={course} /></button><div className="plan-item-copy"><button className="plan-item-title" onClick={() => openCourse(course)}>{course.title}</button><p>{course.teacher}</p><strong>{money(course.price)}</strong><div className="wishlist-item-actions"><button className="text-link" disabled={!course.seats} onClick={() => { addToPlan(course); openPanel("schedule"); }}>{course.seats ? "Add to schedule" : "Class is full"}<Plus size={14} /></button><button className="remove-item" aria-label={`Remove ${course.title} from the shortlist`} onClick={() => toggleSave(course.id)}><X size={16} /></button></div></div></div>)}</div><div className="wishlist-bottom"><button className="button button-outline full-width" onClick={browseFromPanel}>Find another class <ArrowRight size={16} /></button></div></> : <div className="empty-state drawer-empty"><Heart size={49} strokeWidth={1} /><h3>Nothing shortlisted yet.</h3><p>Tap the heart on any class to keep it here<br />while you talk it over at home.</p><button className="button button-primary" onClick={browseFromPanel}>Browse the class list <ArrowRight size={16} /></button></div>}</Dialog>}

      {panel === "enroll" && <Dialog title="Enrollment form" subtitle="A short form — the office handles the rest." onClose={() => setPanel("schedule")} wide><form className="checkout-form" onSubmit={submitEnrollment}><div className="checkout-fields"><div className="demo-notice"><ShieldCheck size={19} /><span><strong>This is a demo enrollment form.</strong>No payment is taken and no seat is actually reserved.</span></div><h3>Who should we expect?</h3><div className="form-row"><label>Guardian first name<input name="firstName" required autoComplete="given-name" maxLength={100} placeholder="First name" /></label><label>Guardian last name<input name="lastName" required autoComplete="family-name" maxLength={100} placeholder="Last name" /></label></div><label>Email address<input name="email" type="email" required autoComplete="email" maxLength={254} placeholder="you@example.com" /></label><label>Phone number<input name="phone" type="tel" required autoComplete="tel" maxLength={40} placeholder="(401) 555-0189" /></label><div className="form-row"><label>Student name<input name="studentName" required maxLength={100} placeholder="Student name" /></label><label>Student grade<select aria-label="Student grade" name="gradeLevel" defaultValue="Grade 3">{["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8"].map((grade) => <option key={grade}>{grade}</option>)}</select></label></div></div><div className="checkout-order"><h3>This term’s schedule</h3>{planCourses.map(({ course, seats }) => <div className="checkout-line" key={course.id}><CourseTile course={course} /><div><strong>{course.title}</strong><small>{seats} seat{seats === 1 ? "" : "s"} · {course.schedule}</small></div><span>{money(course.price * seats)}</span></div>)}<div className="checkout-totals"><div><span>Tuition subtotal</span><span>{money(subtotal)}</span></div><div><span>Multi-class discount</span><span>{discount > 0 ? `− ${money(discount)}` : "—"}</span></div><div className="summary-total"><strong>Total</strong><strong>{money(subtotal - discount)}</strong></div></div>{enrollError && <p className="form-error" role="alert">{enrollError}</p>}<button type="submit" className="button button-primary full-width" disabled={enrollLoading || !plan.length}>{enrollLoading ? "Saving enrollment…" : "Submit demo enrollment"}{!enrollLoading && <ArrowRight size={16} />}</button><p className="checkout-fineprint">The office confirms every place by email within two working days.</p><button type="button" className="continue-browsing" onClick={() => setPanel("schedule")}>← Back to the schedule</button></div></form></Dialog>}

      {panel === "success" && enrollment && <Dialog title="See you in class." onClose={() => setPanel(null)}><div className="order-success"><span className="success-icon"><GraduationCap size={42} strokeWidth={1.3} /></span><p className="eyebrow">THANK YOU FOR CHOOSING LANTERN</p><h3>{enrollment.student}’s demo<br />place is confirmed.</h3><p>We’ve saved this enrollment for <strong>{enrollment.email}</strong>.<br />No payment was taken and no seat is actually reserved.</p><div className="order-receipt"><span>ENROLLMENT NUMBER<strong>{enrollment.reference}</strong></span><span>TERM TOTAL<strong>{money(enrollment.total)}</strong></span></div><button className="button button-primary" onClick={browseFromPanel}>Back to the class list <ArrowRight size={16} /></button></div></Dialog>}

      {panel === "visit" && <Dialog title="Come see the school." subtitle="Open mornings every other Friday." onClose={() => setPanel(null)} wide><div className="visit-dialog"><img src="/images/campus.jpg" alt="Students walking through the school courtyard" /><div><p className="eyebrow">VISIT US ON LANTERN STREET</p><h3>Two buildings,<br />one very good garden.</h3><p>Come see a class in progress, meet the teachers and ask the awkward questions. Visits last about an hour, and children are always welcome.</p><div className="visit-detail"><MapPin size={19} /><span><strong>901 Lantern Street</strong>Providence, RI 02903</span></div><div className="visit-detail"><Clock3 size={19} /><span><strong>Office · Monday–Friday, 8am–6pm</strong>Saturday · 9am–2pm during term</span></div><div className="visit-detail"><Mail size={19} /><a href="mailto:office@lanternacademy.school">office@lanternacademy.school</a></div><a className="button button-primary" href="https://www.google.com/maps/search/?api=1&query=901+Lantern+Street+Providence+RI+02903" target="_blank" rel="noopener noreferrer">Get directions <ArrowUpRight size={16} /></a></div></div></Dialog>}

      {(panel === "tuition" || panel === "withdrawal" || panel === "privacy") && <Dialog title={panel === "tuition" ? "Tuition & payment" : panel === "withdrawal" ? "Enrollment & withdrawal" : "Privacy & your data"} onClose={() => setPanel(null)}><div className="info-dialog">{panel === "tuition" ? <><Sparkles size={38} strokeWidth={1.2} /><h3>Clear pricing, no surprise fees.</h3><p>Tuition is charged per class for the whole term and includes every material, tool and ingredient your child will use.</p><p>Enroll in <strong>three or more seats</strong> — across any classes or siblings — and a <strong>10% multi-class discount</strong> is applied automatically. Need-based scholarships are available for every class; just ask the office.</p><h4>About this site</h4><p>This is a demonstration school website. You can browse classes, build a schedule and submit a demo enrollment. No payment is taken and no seat is actually reserved.</p></> : panel === "withdrawal" ? <><ClipboardCheck size={38} strokeWidth={1.2} /><h3>Plans change. We understand.</h3><p>Places can be withdrawn up to one week before the term starts for a full refund, or swapped for another class with space at any point in the first two weeks.</p><p>If a class is full, join the waitlist and the office will call you the moment a seat opens. Questions? Write to <a href="mailto:office@lanternacademy.school">office@lanternacademy.school</a>.</p><h4>This is a demo school</h4><p>Demo enrollments involve no payment and no real place, so there is nothing to withdraw or refund.</p></> : <><ShieldCheck size={38} strokeWidth={1.2} /><h3>Family data, handled carefully.</h3><p>Your schedule and shortlist are stored in this browser so they’re still here when you come back. Clear them by removing the classes or clearing your browser’s site data.</p><p>If you join the newsletter we store your email address. If you submit a demo enrollment we store the guardian and student details you enter alongside it. No payment information is ever requested or stored.</p><p>For any privacy question or a deletion request, contact <a href="mailto:office@lanternacademy.school">office@lanternacademy.school</a>.</p></>}<button className="button button-outline" onClick={() => setPanel(null)}>Back to the classes <ArrowRight size={16} /></button></div></Dialog>}
    </>
  );
}
