import assert from "node:assert/strict";
import { chromium } from "playwright";

const origin = process.env.TEST_ORIGIN || "http://localhost:3000";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
const email = `lantern-qa-${Date.now()}@example.com`;

try {
  const response = await page.goto(origin, { waitUntil: "networkidle" });
  assert.equal(response.status(), 200);
  await page.getByRole("heading", { level: 1, name: /Where curiosity/ }).waitFor();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  console.log("PASS: Homepage and desktop layout");

  const firstPick = page.locator(".pick-shelf .course-card").first();
  await firstPick.getByRole("button", { name: /Save Messy Paint Studio/ }).click();
  await page.getByRole("button", { name: /Open shortlist/ }).click();
  await page.getByRole("dialog").waitFor();
  assert.equal(await page.locator(".wishlist-items .plan-item").count(), 1);
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page.reload({ waitUntil: "networkidle" });
  assert.deepEqual(await page.evaluate(() => JSON.parse(localStorage.getItem("lantern-shortlist"))), ["messy-paint-studio"]);
  console.log("PASS: Shortlist persists across reloads");

  const search = page.getByRole("searchbox").or(page.getByRole("textbox", { name: "Search classes, teachers, and subjects" }));
  await search.fill("Robotics");
  await search.press("Enter");
  await page.waitForFunction(() => document.querySelectorAll(".catalog-grid .course-card").length === 1);
  assert.match(await page.locator(".catalog-grid .course-title").textContent(), /Robotics Sandbox/);
  await search.fill("");
  await search.press("Escape");
  await page.locator(".category-tabs").getByRole("button", { name: "Science", exact: true }).click();
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 3);
  await page.getByRole("combobox", { name: "Sort classes" }).selectOption("tuition-low");
  assert.match(await page.locator(".catalog-grid .course-title").first().textContent(), /Backyard Naturalists/);
  await page.getByRole("button", { name: "Filters", exact: true }).click();
  await page.getByLabel("Seats available", { exact: true }).check();
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 2);
  await page.getByLabel("Grade band", { exact: true }).selectOption("lower");
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 1);
  await page.getByLabel("Early-bird rate", { exact: true }).check();
  await page.getByRole("heading", { name: "No classes match just yet." }).waitFor();
  await page.getByRole("button", { name: "Show all classes", exact: true }).click();
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 8);
  await page.getByRole("button", { name: "Show more classes" }).click();
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 16);
  await page.getByRole("button", { name: "Show more classes" }).click();
  assert.equal(await page.locator(".catalog-grid .course-card").count(), 24);
  console.log("PASS: Search, subjects, sorting, filters, empty state, and pagination");

  await page.getByRole("button", { name: "Next teacher picks" }).click();
  await page.waitForFunction(() => document.querySelector(".pick-shelf").scrollLeft > 10);
  await page.getByRole("button", { name: "Previous teacher picks" }).click();
  await page.waitForFunction(() => document.querySelector(".pick-shelf").scrollLeft < 10);
  console.log("PASS: Teacher picks carousel");

  await firstPick.locator(".course-title").click();
  await page.getByRole("dialog").waitFor();
  assert.match(await page.locator(".course-facts").textContent(), /Tuesdays · 4:00pm/);
  await page.getByRole("button", { name: "More seats", exact: true }).click();
  await page.getByRole("button", { name: "Add to schedule", exact: true }).click();
  await page.getByRole("heading", { name: "Your class schedule", exact: true }).waitFor();
  assert.equal(await page.locator(".plan-item .quantity-control span").textContent(), "2");
  assert.match(await page.locator(".discount-progress").textContent(), /1 more seat to save 10%/);
  await page.getByRole("button", { name: "More seats for Messy Paint Studio" }).click();
  assert.equal(await page.locator(".plan-item .quantity-control span").textContent(), "3");
  assert.match(await page.locator(".discount-progress").textContent(), /discount applied/);
  assert.match(await page.locator(".plan-summary").textContent(), /−\s?\$54\.00/);
  assert.match(await page.locator(".plan-summary .summary-total").textContent(), /486\.00/);
  await page.getByRole("button", { name: "Continue to enrollment" }).click();
  await page.getByLabel("Guardian first name", { exact: true }).fill("Alex");
  await page.getByLabel("Guardian last name", { exact: true }).fill("Rivera");
  await page.getByLabel("Email address", { exact: true }).fill(email);
  await page.getByLabel("Phone number", { exact: true }).fill("(401) 555-0189");
  await page.getByLabel("Student name", { exact: true }).fill("Robin Rivera");
  await page.getByLabel("Student grade", { exact: true }).selectOption("Grade 2");
  await page.getByRole("button", { name: "Submit demo enrollment" }).click();
  await page.getByRole("heading", { name: /Robin Rivera.s demo/ }).waitFor();
  assert.match(await page.locator(".order-receipt").textContent(), /LA-[A-F0-9]{8}/);
  assert.match(await page.locator(".order-receipt").textContent(), /486\.00/);
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem("lantern-schedule")).length), 0);
  console.log("PASS: Class details, seat controls, multi-class discount, and saved demo enrollment");
  console.log("Test receipt:", await page.locator(".order-receipt").textContent());
  await page.getByRole("button", { name: "Back to the class list" }).click();

  await page.waitForFunction(() => !document.querySelector("dialog[open]"));
  assert.match(await page.locator(".course-card", { hasText: "Messy Paint Studio" }).first().textContent(), /3 seats left/);
  console.log("PASS: Remaining seats decrease after enrollment");

  await page.getByLabel("Your email address", { exact: true }).fill(email);
  await page.getByRole("button", { name: "Subscribe to the Lantern Academy newsletter" }).click();
  await page.getByText("Welcome to the school list.", { exact: true }).waitFor();
  console.log("PASS: Newsletter signup");

  const badEmail = await context.request.post(`${origin}/api/newsletter`, { data: { email: "not-an-email" } });
  assert.equal(badEmail.status(), 400);
  const badEnrollment = await context.request.post(`${origin}/api/enrollments`, { data: { items: [] } });
  assert.equal(badEnrollment.status(), 400);
  const fullClass = await context.request.post(`${origin}/api/enrollments`, { data: { guardian: { firstName: "A", lastName: "B", email: "a@b.com", phone: "4015550189", studentName: "C", gradeLevel: "Grade 7" }, items: [{ courseId: "marine-biology-club", seats: 1 }] } });
  assert.equal(fullClass.status(), 409);
  const classList = await context.request.get(`${origin}/api/courses?q=Robotics`);
  assert.equal((await classList.json()).total, 1);
  console.log("PASS: Server-side validation, full-class guard, and class API");

  const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const phone = await mobile.newPage();
  phone.on("pageerror", (error) => errors.push(error.message));
  await phone.goto(origin, { waitUntil: "networkidle" });
  assert.equal(await phone.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await phone.getByRole("button", { name: "Open menu", exact: true }).click();
  await phone.locator(".mobile-nav").getByRole("link", { name: "Class list" }).waitFor();
  await phone.getByRole("button", { name: "Close menu", exact: true }).click();
  await phone.getByRole("button", { name: "Search classes", exact: true }).click();
  const mobileSearch = phone.getByRole("textbox", { name: "Search classes, teachers, and subjects" });
  await mobileSearch.fill("Ukulele");
  await mobileSearch.press("Enter");
  await phone.locator(".catalog-grid .course-title").click();
  await phone.getByRole("button", { name: "Add to schedule", exact: true }).click();
  await phone.getByRole("heading", { name: "Your class schedule", exact: true }).waitFor();
  assert.equal(await phone.locator(".plan-item").count(), 1);
  await phone.getByRole("button", { name: "Remove First Ukulele from the schedule" }).click();
  await phone.getByRole("heading", { name: "Your term starts here." }).waitFor();
  await phone.getByRole("button", { name: "Close dialog" }).click();
  console.log("PASS: Mobile navigation, search, class dialog, schedule, and removal");
  assert.deepEqual(errors, []);
  console.log("PASS: No browser runtime errors");
  await mobile.close();
} finally {
  await browser.close();
}
